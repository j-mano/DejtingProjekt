﻿using System.Web;
using System.Web.Mvc;

namespace DejtProjekt
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());

            //La till global Authorize
            filters.Add(new AuthorizeAttribute());
        }
    }
}
