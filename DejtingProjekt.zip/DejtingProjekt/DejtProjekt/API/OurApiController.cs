﻿using DejtProjekt.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Web.Http;
using System.Web.Http.OData;



namespace DejtProjekt.API
{
    [Authorize] 
    public class OurApiController : ApiController
    {
        private OurDbContext db = new OurDbContext();
        
        /// <summary>
        /// Hämtar meddelanden och författaren genom en linq sats
        /// </summary>
        // GET api/Posts/   
        public IHttpActionResult GetPost(int id)
        {
           
            var joinQuery = from user in db.userModel
                            join post in db.Posts on user.UserID equals post.AuthorId
                            where post.WallId == id
                            select new { post.Message, user.Username };

            return Ok(joinQuery);
        }


        /// <summary>
        /// Sparar meddelanden i databasen
        /// </summary>
        // GET api/Posts/   
        // POST api/Posts   
        [HttpPost]
        public IHttpActionResult PostPost(Post post)
         {
             if (ModelState.IsValid)
             {
                 db.Posts.Add(post);
                 db.SaveChanges();
                 var uri = new Uri( Url.Link(                    
                     "DefaultApi",                   
                     new { id = post.MessageId }));
                 return Created(uri, post);
             }
             else
             {
                 return BadRequest(ModelState);
             }
         }
      
        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}
